<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

$id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username,email,created_at FROM users WHERE id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$stmt->bind_result($username,$email,$created_at);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Profile</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>User Profile</h2>
<p><strong>Username:</strong> <?php echo htmlspecialchars($username); ?></p>
<p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
<p><strong>Joined:</strong> <?php echo $created_at; ?></p>

<form method="POST" action="logout.php">
<button type="submit">Logout</button>
</form>
</div>
</body>
</html>
