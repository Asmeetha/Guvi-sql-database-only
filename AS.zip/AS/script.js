const BASE = ''; // leave empty if all files are in the same folder

// Load profile using fetch
function loadProfile() {
  fetch(BASE + '/profile.php')
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        document.getElementById('profile').innerHTML = `
          <p><strong>Username:</strong> ${data.username}</p>
          <p><strong>Email:</strong> ${data.email}</p>
          <p><strong>Joined:</strong> ${data.joined}</p>
        `;
      } else {
        alert(data.message);
        window.location.href = 'login.html';
      }
    });
}

// Logout using fetch
function logoutUser() {
  fetch(BASE + '/logout.php')
    .then(res => res.json())
    .then(data => {
      alert(data.message);
      window.location.href = 'login.html';
    });
}
